<?php
define('host','localhost');
define('username','root');
define('password','');
define('db','chatBot');
